const state = {
    token: "",
    userId: "",
    roleId:"",
    expirationDate:""
}

export default state