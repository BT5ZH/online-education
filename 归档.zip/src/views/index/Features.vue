<template>
    <section class="features">
        <div class="feature">
            <svg class="feature__icon">
                <use xlink:href="../../assets/img/sprite.svg#icon-global"></use>
            </svg>
            <h4 class="heading-4 heading-4--dark">学习计划</h4>
            <p class="feture-text">学习计划</p>
        </div>
        <div class="feature">
            <svg class="feature__icon">
                <use xlink:href="../../assets/img/sprite.svg#icon-global"></use>
            </svg>
            <h4 class="heading-4 heading-4--dark">学习计划</h4>
            <p class="feture-text">学习计划</p>
        </div>
        <div class="feature">
            <svg class="feature__icon">
                <use xlink:href="../../assets/img/sprite.svg#icon-global"></use>
            </svg>
            <h4 class="heading-4 heading-4--dark">学习计划</h4>
            <p class="feture-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa dolores modi sunt nihil
                pariatur non ducimus, labore, ex ratione nobis minus distinctio esse nesciunt impedit debitis explicabo!
                Quod, magnam illo.</p>
        </div>
        <div class="feature">
            <svg class="feature__icon">
                <use xlink:href="../../assets/img/sprite.svg#icon-global"></use>
            </svg>
            <h4 class="heading-4 heading-4--dark">学习计划</h4>
            <p class="feture-text">学习计划</p>
        </div>
        <div class="feature">
            <svg class="feature__icon">
                <use xlink:href="../../assets/img/sprite.svg#icon-global"></use>
            </svg>
            <h4 class="heading-4 heading-4--dark">学习计划</h4>
            <p class="feture-text">学习计划</p>
        </div>
        <div class="feature">
            <svg class="feature__icon">
                <use xlink:href="../../assets/img/sprite.svg#icon-global"></use>
            </svg>
            <h4 class="heading-4 heading-4--dark">学习计划</h4>
            <p class="feture-text">学习计划</p>
        </div>
    </section>
</template>