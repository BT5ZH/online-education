<template>
    <footer class="footer">
        <ul class="nav">
            <li class="nav__item"><a href="#" class="nav__link">发现</a></li>
            <li class="nav__item"><a href="#" class="nav__link">咨询</a></li>
            <li class="nav__item"><a href="#" class="nav__link">联系我们</a></li>
            <li class="nav__item"><a href="#" class="nav__link">学习计划</a></li>
            <li class="nav__item"><a href="#" class="nav__link">学习计划</a></li>
            <li class="nav__item"><a href="#" class="nav__link">加入我们</a></li>
        </ul>
        <p class="copyright">
            &copy; 版权 2019 研创未来--在线教育 Feel free to use thisproject for your own puuposes.
            This does NOT apply if you plan to produce your own course or tutorials based on this project.
        </p>
    </footer>
</template>
<style>
    
</style>