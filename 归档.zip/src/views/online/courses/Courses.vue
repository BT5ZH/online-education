<template>
    <main class="rs-courses">
        <div class="courses-list">
            <div class="course">
                <img src="../../../assets/img/house-1.jpeg" alt="House 1" class="course__img">
                <svg class="course__like">
                    <use xlink:href="../../../assets/img/sprite.svg#icon-heart-full"></use>
                </svg>
                <h5 class="course__name">Beautiful Family House</h5>
                <div class="course__title">
                    计算机基础
                </div>
                <div class="course__author">
                    <p>张汇泉</p>
                </div>
                <div class="course__price">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-key"></use>
                    </svg>
                    <p>$20,000</p>
                </div>
                <button class="online-btn course__btn"><router-link to="/learning">开始学习</router-link></button>

            </div>
            <div class="course">
                <img src="../../../assets/img/house-2.jpeg" alt="House 2" class="course__img">
                <svg class="course__like">
                    <use xlink:href="../../../assets/img/sprite.svg#icon-heart-full"></use>
                </svg>
                <h5 class="course__name">Beautiful Family House</h5>
                <div class="course__title">
                    计算机基础
                </div>
                <div class="course__author">
                    <p>张汇泉</p>
                </div>
                <div class="course__price">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-key"></use>
                    </svg>
                    <p>$20,000</p>
                </div>
                <button class="online-btn course__btn">开始学习</button>
            </div>
            <div class="course">
                <img src="../../../assets/img/house-3.jpeg" alt="House 3" class="course__img">
                <svg class="course__like">
                    <use xlink:href="../../../assets/img/sprite.svg#icon-heart-full"></use>
                </svg>
                <h5 class="course__name">Beautiful Family House</h5>
                <div class="course__title">
                    计算机基础
                </div>
                <div class="course__author">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-profile-male"></use>
                    </svg>
                    <p>张汇泉</p>
                </div>
                <div class="course__student">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-profile-male"></use>
                    </svg>
                    <p>125</p>
                </div>
                <div class="course__rank">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite2.svg#icon-star"></use>
                    </svg>
                    <p>125</p>
                </div>
                <div class="course__price">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-key"></use>
                    </svg>
                    <p>$20,000</p>
                </div>
                <button class="online-btn course__btn">开始学习</button>
            </div>
            <div class="course">
                <img src="../../../assets/img/house-3.jpeg" alt="House 3" class="course__img">
                <svg class="course__like">
                    <use xlink:href="../../../assets/img/sprite.svg#icon-heart-full"></use>
                </svg>
                <h5 class="course__name">Beautiful Family House</h5>
                <div class="course__title">
                    计算机基础
                </div>
                <div class="course__author">
                    <p>张汇泉</p>
                </div>
                <div class="course__price">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-key"></use>
                    </svg>
                    <p>$20,000</p>
                </div>
                <button class="online-btn course__btn">开始学习</button>
            </div>
            <div class="course">
                <img src="../../../assets/img/house-3.jpeg" alt="House 3" class="course__img">
                <svg class="course__like">
                    <use xlink:href="../../../assets/img/sprite.svg#icon-heart-full"></use>
                </svg>
                <h5 class="course__name">Beautiful Family House</h5>
                <div class="course__title">
                    计算机基础
                </div>
                <div class="course__author">
                    <p>张汇泉</p>
                </div>
                <div class="course__price">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-key"></use>
                    </svg>
                    <p>$20,000</p>
                </div>
                <button class="online-btn course__btn">开始学习</button>
            </div>
            <div class="course">
                <img src="../../../assets/img/house-3.jpeg" alt="House 3" class="course__img">
                <svg class="course__like">
                    <use xlink:href="../../../assets/img/sprite.svg#icon-heart-full"></use>
                </svg>
                <h5 class="course__name">Beautiful Family House</h5>
                <div class="course__title">
                    计算机基础
                </div>
                <div class="course__author">
                    <p>张汇泉</p>
                </div>
                <div class="course__price">
                    <svg>
                        <use xlink:href="../../../assets/img/sprite.svg#icon-key"></use>
                    </svg>
                    <p>$20,000</p>
                </div>
                <button class="online-btn course__btn">开始学习</button>
            </div>


        </div>
        <div class="sts-info">
            test
        </div>
    </main>
</template>
<style>
    .test {
        background-image: url("../../../assets/img/sprite.svg#icon-heart-full");
    }
</style>