import Vue from 'vue';
import VueRouter from 'vue-router';
import Online from './Online.vue';
import {routes} from './router';
import axios from 'axios';
import {store} from '../../store/index';

Vue.use(VueRouter);

Vue.prototype.axios = axios;

const router = new VueRouter({
    routes,
});
new Vue({
    router,
    store,
    render: h => h(Online)
}).$mount('#online')