/**
*
* @author louie
* @date created in 2018-10-9 10:41
*/
<template>
    <div class="test">
        <a href="">this is client login</a>
        
        <p class="nimabi">ge molestias officia porro minima eveniet. Odit, aliquam minima a libero quas illum incidunt consequatur rem nulla!</p>
    </div>
</template>

<script>
    export default {
        name: "login"
    }
</script>

<style lang="scss">

</style>