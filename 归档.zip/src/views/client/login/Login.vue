
<template>
    <div class="">
        <a href="">this is client login</a>
        
        <p class="">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate laudantium eveniet cum? Sit labore molestias officia porro minima eveniet. Odit, aliquam minima a libero quas illum incidunt consequatur rem nulla!</p>
    </div>
</template>

<script>
    export default {
        name: "login"
    }
</script>

<style lang="scss">

/* .test {
    color: $color-primary;
    &__text {
        color:$color-primary;
    }
} */
</style>